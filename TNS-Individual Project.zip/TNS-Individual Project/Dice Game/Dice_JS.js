//player 01 logic  
var Dice1 = Math.floor(Math.random() * 6) + 1;
var randomImageSource = "Dice/Dice" + Dice1 + ".png";
var image1 =  document.querySelectorAll("img")[0];
image1.setAttribute("src", randomImageSource);


// Player 2 logic
var Dice2 = Math.floor(Math.random() * 6) + 1;
var randomImageSource2 = "Dice/Dice" + Dice2 + ".png";
var image2 = document.querySelectorAll("img")[1];
image2.setAttribute("src", randomImageSource2);

// Player 3 logic
var Dice3 = Math.floor(Math.random() * 6) + 1;
var randomImageSource3 = "Dice/Dice" + Dice3 + ".png";
var image3 = document.querySelectorAll("img")[2];
image3.setAttribute("src", randomImageSource3);

// Player 4 logic
var Dice4 = Math.floor(Math.random() * 6) + 1;
var randomImageSource4 = "Dice/Dice" + Dice4 + ".png";
var image4 = document.querySelectorAll("img")[3];
image4.setAttribute("src", randomImageSource4);



// Main Logic of Dice
var scores = [Dice1, Dice2, Dice3, Dice4];
var maxScore = Math.max(...scores);
var winners = [];

for (var i = 0; i < scores.length; i++) {
    if (scores[i] === maxScore) {
        winners.push("Player " + (i + 1));
    }
}

document.querySelector("h1").innerHTML = winners.length > 1 ? winners.join(", ") + " Draw!" : winners[0] + " Wins!";
