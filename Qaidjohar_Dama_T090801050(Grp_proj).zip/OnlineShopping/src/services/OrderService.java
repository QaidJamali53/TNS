package services;

import java.util.*;

import entities.Order;
import entities.Product;
import entities.ProductQuantityPair;

public class OrderService {
    private List<Order> orderList = new ArrayList<>();

    public void placeOrder(Order order) {
        orderList.add(order);
        System.out.println("Order placed successfully!");
    }

    public void updateOrderStatus(Scanner scanner) {
        System.out.print("Enter Order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter New Status (Pending/Completed/Delivered/Cancelled): ");
        String status = scanner.nextLine();
        Order order = getOrder(orderId);
        if (order != null) {
            order.setStatus(status);
            System.out.println("Order status updated.");
        } else {
            System.out.println("Order not found.");
        }
    }

    public void viewOrders() {
        if (orderList.isEmpty()) {
            System.out.println("No orders placed yet.");
            return;
        }
        orderList.forEach(System.out::println);
    }

    public Order getOrder(int orderId) {
        return orderList.stream().filter(o -> o.getOrderId() == orderId).findFirst().orElse(null);
    }
}
