package services;

import entities.*;
import java.util.*;

// Product Service
public class ProductService {
    private List<Product> productList = new ArrayList<>();

    public void addProduct(Scanner scanner) {
        System.out.print("Enter Product ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Product Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Product Price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter Stock Quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();

        productList.add(new Product(id, name, price, quantity));
        System.out.println("Product added successfully!");
    }

    public void removeProduct(Scanner scanner) {
        System.out.print("Enter Product ID to remove: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        productList.removeIf(product -> product.getProductId() == id);
        System.out.println("Product removed successfully!");
    }

    public void viewProducts() {
        if (productList.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        productList.forEach(System.out::println);
    }

    public Product getProductById(int productId) {
        return productList.stream().filter(p -> p.getProductId() == productId).findFirst().orElse(null);
    }

    public void addSampleData() {
        productList.add(new Product(1, "Laptop", 50000, 10));
        productList.add(new Product(2, "Phone", 20000, 15));
    }
}
